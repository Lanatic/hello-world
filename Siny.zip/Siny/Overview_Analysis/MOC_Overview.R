library(readxl)
library(dplyr)
library(zoo)
MOC <- read_excel("E:/Intelligence-Analysis Team/4.Staff Working Folders/Jiabin/Sentiment/Overview_Analysis/Combined MOC cleaned by Lana.xlsx")
# RB is the subject 


MOC <- MOC[,c(4:7)]
MOC <- MOC %>% filter(!is.na(Sender))


unique_individuals <- unique(c(unique(MOC$Sender), unique(MOC$Receiver)))
# Indentify the main individuals they talk too
Main_Indiv <- data.frame(cbind(0,0))

for(i in unique_individuals){
  Indiv <- MOC %>% filter(Sender==i|Receiver==i)
  Indiv <- Indiv[!duplicated(Indiv),]
    Main_Indiv <- rbind(Main_Indiv,c(i, nrow(Indiv)))
    colnames(Main_Indiv) <- c("Individual","Lines")
}

# Who do they talk to?
# How often #Days and how frequency #Time per day do they talk to that person
Main_Indiv$Lines <- as.numeric(Main_Indiv$Lines)
Rank_Indiv <- Main_Indiv[order(Main_Indiv$Lines, decreasing = TRUE),][-1,]
Top_Indiv <- Rank_Indiv[order(Rank_Indiv$Lines, decreasing = TRUE),][1:10,]

# how often #Days and frequency #Time per day
unique(Top_Indiv$Individual)
Frequency <- data.frame(0,0,0)

for(i in unique(Top_Indiv$Individual)){
  Days <- MOC %>% filter(Sender==i|Receiver==i)
  Days <- Days[!duplicated(Days),]
  Days$`Message Time__1` <- as.Date(Days$`Message Time__1`)
  for(j in unique(Days$`Message Time__1`)){
    Count <- Days %>% filter(`Message Time__1`==j) %>% nrow()
    Frequency <- rbind(Frequency, c(i,j,Count))
  }
}

Frequency <- Frequency[-1,]
Frequency$X0.1 <- as.Date(as.numeric(Frequency$X0.1))
colnames(Frequency) <- c("Individual", "Date", "Lines")

#
# What can we say about the communication- swearing? work related?





