# KPI Dashboard
library(readr)
library(ggplot2)
library(shinydashboard)
library(shiny)
library(dplyr)
library(plotly)

sidebar <- dashboardSidebar(
  sidebarMenu(
    menuItem("Word Clouds", tabName="Sub_Word_Clouds", icon=icon("dashboard"))
  )
)
body <- dashboardBody(
  tabItem("Sub_Word_Clouds",
          fluidRow(
            column(12,
            selectInput("selection", "Choose an individual:",
                        choices =Individuals),
            actionButton("update","Change"),
            hr(),
            
            sliderInput("freq",
                        "Minimum Frequency:",
                        min=1,max=50,value=5),
            sliderInput("max", "Maximum Number of Words:",
                        min=1,max=300,value=100)),
            br(),
            column(6,h4("Entire Wordcloud"),
            plotOutput("Sub_Wordcloud")),
            column(6,h4("Negative Wordcloud"),
            plotOutput("Neg_Sub_Wordcloud"))
            
          )))

ui <- dashboardPage(
  dashboardHeader(title = "Sentiment Analysis"),
  sidebar,
  body
)
