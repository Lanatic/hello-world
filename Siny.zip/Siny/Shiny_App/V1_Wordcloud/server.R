#Load up appropriate libraries
library(readxl)
library(readr)
library(dplyr)
library(tm)
library(SnowballC)
library(wordcloud)
library(memoise)
library(sentimentr)
library(tidytext)
library(RColorBrewer)

Bulk_Data <- read_csv("I:/Detection Team Working Folder/Jiabin/Sentiment/Shiny_App/DOLOS.csv")
Bulk_Data$Sender <- toupper(Bulk_Data$Sender)
Bulk_Data$Receiver <- toupper(Bulk_Data$Receiver)
DOLOS_List <- read_excel("I:/Detection Team Working Folder/Jiabin/Sentiment/DOLOS_Email_List.xlsx", col_names = FALSE)
unique_DOLOS <- data.frame(unique(DOLOS_List$X__2))  
unique_DOLOS <- data.frame(lapply(unique_DOLOS, na.omit))
colnames(unique_DOLOS) <- "Email"
unique_DOLOS$Email <- toupper(unique_DOLOS$Email)
Individuals <- as.list(unique_DOLOS$Email)

sentiments <- get_sentiments("bing")
negative_sentiments <- sentiments %>% filter(sentiment=="negative")

toSpace <- content_transformer(function (x , pattern ) gsub(pattern, " ", x))

# Need to add functionailty to include very large MOC files
D_Trans_Neg <- function(x){
  x <- tm_map(x, toSpace, "/")
  x <- tm_map(x, toSpace, "@")
  x <- tm_map(x, toSpace, "\\|")
  x <- tm_map(x, content_transformer(tolower))
  x <- tm_map(x, removeNumbers)
  x <- tm_map(x, removeWords, stopwords("english"))
  x <- tm_map(x, removePunctuation)
  x <- tm_map(x, stripWhitespace)
  dtm <- TermDocumentMatrix(x)
  m <- as.matrix(dtm)
  v <- sort(rowSums(m),decreasing=TRUE)
  i <- data.frame(word=names(v), freq=v)
  negative_matches <- intersect(i$word, negative_sentiments$word)
  i %>% filter(word %in% negative_matches)
  
}


D_Trans <- function(x){
  x <- tm_map(x, toSpace, "/")
  x <- tm_map(x, toSpace, "@")
  x <- tm_map(x, toSpace, "\\|")
  x <- tm_map(x, content_transformer(tolower))
  x <- tm_map(x, removeNumbers)
  x <- tm_map(x, removeWords, stopwords("english"))
  x <- tm_map(x, removePunctuation)
  x <- tm_map(x, stripWhitespace)
  dtm <- TermDocumentMatrix(x)
  m <- as.matrix(dtm)
  sort(rowSums(m),decreasing=TRUE)
  #i <<- data.frame(word=names(v), freq=v)
  
}



getTermMatrix <- memoise(function(individual){
  if(!(individual %in% individual ))
    stop("Unknown Individual")
  
  Single_User <- Bulk_Data %>% filter(Sender==individual|Receiver==individual)
  Message_String <- paste0(Single_User$Message)
  Docs <- Corpus(VectorSource(Message_String))
  D_Trans(Docs)
  
})

getTermMatrix_Neg <- (function(individual){
  if(!(individual %in% individual ))
    stop("Unknown Individual")
  
  Single_User <- Bulk_Data %>% filter(Sender==individual|Receiver==individual)
  Message_String <- paste0(Single_User$Message)
  Docs <- Corpus(VectorSource(Message_String))
  D_Trans_Neg(Docs)
})


# Server.ui
server = function(input, output){
  terms <- reactive({
    input$update
    
    isolate({
      withProgress({
        setProgress(message="Processing MOC...")
        getTermMatrix(input$selection)
      })
    })
  })
  
  
  terms_neg <- reactive({
    input$update
    
    isolate({
      withProgress({
        setProgress(message="Processing MOC...")
        getTermMatrix_Neg(input$selection)
      })
    })
  })
  
  
  wordcloud_rep <- repeatable(wordcloud)
  
  output$Sub_Wordcloud <-renderPlot({
    v<-terms()
    wordcloud_rep(names(v), v, scale=c(4,0.5),
                  min.freq=input$freq, max.words=input$max,
                  colors=brewer.pal(8,"Dark2"))
  })
  
  output$Neg_Sub_Wordcloud <-renderPlot({
    v <- terms_neg()
    wordcloud(v$word, v$freq, scale=c(4,0.5),
                  min.freq=input$freq, max.words=input$max,
                  colors=brewer.pal(8,"Dark2"))
  })
  
    
  
}
