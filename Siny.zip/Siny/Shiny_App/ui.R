# KPI Dashboard
library(readr)
library(ggplot2)
library(shinydashboard)
library(shiny)
library(dplyr)
library(plotly)
library(readxl)
library(DT)

#Read in unique list of DOLOS users
DOLOS_List <- read_excel("I:/Detection Team/Working Folder/Jiabin/Sentiment/DOLOS_Email_List.xlsx", col_names = FALSE)
unique_DOLOS <- data.frame(unique(DOLOS_List$X__2))  
unique_DOLOS <- data.frame(lapply(unique_DOLOS, na.omit))
colnames(unique_DOLOS) <- "Email"
unique_DOLOS$Email <- toupper(unique_DOLOS$Email)
Individuals <- as.list(unique_DOLOS$Email)

sidebar <- dashboardSidebar(
  sidebarMenu(
    menuItem("Word Clouds", tabName="Sub_Word_Clouds", icon=icon("dashboard")),
    menuItem("Data table", tabName="Table_Summary", icon=icon("dashboard")),
    menuItem("Time Series Plot", tabName="TS_Plot", icon=icon("dashboard"))
    
  )
)
body <- dashboardBody(
  tabItems(
    tabItem("Sub_Word_Clouds",
          fluidRow(
            column(12,
            selectInput("selection", "Choose an individual:",
                        choices =Individuals),
            actionButton("update","Change"),
            hr(),
            
            sliderInput("freq",
                        "Minimum Frequency:",
                        min=1,max=50,value=5),
            sliderInput("max", "Maximum Number of Words:",
                        min=1,max=300,value=100)),
            br(),
            column(6,h4("Entire Wordcloud"),
            plotOutput("Sub_Wordcloud")),
            column(6,h4("Negative Wordcloud"),
            plotOutput("Neg_Sub_Wordcloud"))
            
          )),
  
  tabItem("Table_Summary",
          h4("Summary of words used in MOC"),
          dataTableOutput("Word_Summary"),
          dataTableOutput("Show_Sentences")),
  tabItem("TS_Plot",
          plotlyOutput("TSPlot"))
  
  ))

ui <- dashboardPage(
  dashboardHeader(title = "Sentiment Analysis"),
  sidebar,
  body
)
