#Load up appropriate libraries
library(readxl)
library(readr)
library(dplyr)
library(tm)
library(SnowballC)
library(wordcloud)
library(memoise)
library(sentimentr)
library(tidytext)
library(RColorBrewer)
library(zoo)
library(DT)

# Read bulk moc data and clean up file
Bulk_Data <- read_csv("I:/Detection Team Working Folder/Jiabin/Sentiment/Shiny_App/DOLOS.csv")
Bulk_Data$Sender <- toupper(Bulk_Data$Sender)
Bulk_Data$Receiver <- toupper(Bulk_Data$Receiver)


# Filter out negative sentiments
sentiments <- get_sentiments("bing")
negative_sentiments <- sentiments %>% filter(sentiment=="negative")


#Data table for matched words as well as Frequency
#Substantiated unique negative words
Sub_Unique_Neg <- read_csv("I:/Detection Team Working Folder/Jiabin/Sentiment/Word_Matches/Sub_Unique_Neg.csv")
Sub_Unique_Neg <- Sub_Unique_Neg[,c(4:5)]

#DLP key words 
DLP_Extremism <- read_excel("I:/Detection Team Working Folder/Jiabin/Sentiment/DLP Keyword List.xlsx", 
                               sheet = "Extremism")

DLP_Important_Persons <- read_excel("I:/Detection Team Working Folder/Jiabin/Sentiment/DLP Keyword List.xlsx", 
                               sheet = "Important Persons")


DLP_Media_Comm <- read_excel("I:/Detection Team Working Folder/Jiabin/Sentiment/DLP Keyword List.xlsx", 
                               sheet = "Media Communications")

DLP_Organised_Crime <- read_excel("I:/Detection Team Working Folder/Jiabin/Sentiment/DLP Keyword List.xlsx", 
                               sheet = "Organised Crime")

#HR negative words combined with words from design and change management team


#MOC_Acroynms 
MOC_Acroynms <- read_excel("I:/Detection Team Working Folder/Jiabin/Sentiment/Word_Matches/MOC_Acroynms.xlsx")


# Functions to clean up MOC data 
toSpace <- content_transformer(function (x , pattern ) gsub(pattern, " ", x))

D_Trans_Word_Matches <- function(x){
  x <- tm_map(x, toSpace, "/")
  x <- tm_map(x, toSpace, "@")
  x <- tm_map(x, toSpace, "\\|")
  x <- tm_map(x, content_transformer(tolower))
  x <- tm_map(x, removeNumbers)
  x <- tm_map(x, removeWords, stopwords("english"))
  x <- tm_map(x, removePunctuation)
  x <- tm_map(x, stripWhitespace)
  dtm <- TermDocumentMatrix(x)
  m <- as.matrix(dtm)
  v <- sort(rowSums(m),decreasing=TRUE)
  i <- data.frame(word=names(v), freq=v)
  Extremism <-i %>% filter(word %in% DLP_Extremism$Extremism)%>% mutate(Category="Extremism")
  Imp_Person <- i %>% filter(word %in% DLP_Important_Persons$`Important Persons`)%>% mutate(Category="Important Persons")
  Media_Comms <-i %>% filter(word %in% DLP_Media_Comm$`Media Communications`) %>% mutate(Category="Media Communications")
  Organised_Crime <- i %>% filter(word %in% DLP_Organised_Crime$`Organised Crime`) %>% mutate(Category="Organised Crime")
  Sub_Unique <- i %>% filter(word %in% Sub_Unique_Neg$Word) %>% mutate(Category="Unique Substantiated words")
  MOC_Ac <<- i %>% filter(word %in% MOC_Acroynms$`ATO Officer's MOC`) %>% mutate(Category="MOC Acroynms")
  Result <<- data.frame(rbind(Extremism,Imp_Person,Media_Comms,Organised_Crime,Sub_Unique,MOC_Ac))
  colnames(Result) <<- c("Word", "Frequency","Category")
}


# Need to add functionailty to include very large MOC files
D_Trans_Neg <- function(x){
  x <- tm_map(x, toSpace, "/")
  x <- tm_map(x, toSpace, "@")
  x <- tm_map(x, toSpace, "\\|")
  x <- tm_map(x, content_transformer(tolower))
  x <- tm_map(x, removeNumbers)
  x <- tm_map(x, removeWords, stopwords("english"))
  x <- tm_map(x, removePunctuation)
  x <- tm_map(x, stripWhitespace)
  dtm <- TermDocumentMatrix(x)
  m <- as.matrix(dtm)
  v <- sort(rowSums(m),decreasing=TRUE)
  i <- data.frame(word=names(v), freq=v)
  negative_matches <- intersect(i$word, negative_sentiments$word)
  i %>% filter(word %in% negative_matches)
  
}


D_Trans <- function(x){
  x <- tm_map(x, toSpace, "/")
  x <- tm_map(x, toSpace, "@")
  x <- tm_map(x, toSpace, "\\|")
  x <- tm_map(x, content_transformer(tolower))
  x <- tm_map(x, removeNumbers)
  x <- tm_map(x, removeWords, stopwords("english"))
  x <- tm_map(x, removePunctuation)
  x <- tm_map(x, stripWhitespace)
  dtm <- TermDocumentMatrix(x)
  m <- as.matrix(dtm)
  sort(rowSums(m),decreasing=TRUE)
  #i <<- data.frame(word=names(v), freq=v)
  
}



getTermMatrix <- memoise(function(individual){
  if(!(individual %in% individual ))
    stop("Unknown Individual")
  
  Single_User <- Bulk_Data %>% filter(Sender==individual|Receiver==individual)
  Message_String <- paste0(Single_User$Message)
  Docs <- Corpus(VectorSource(Message_String))
  D_Trans(Docs)
  
})

getTermMatrix_Neg <- (function(individual){
  if(!(individual %in% individual ))
    stop("Unknown Individual")
  
  Single_User <- Bulk_Data %>% filter(Sender==individual|Receiver==individual)
  Message_String <- paste0(Single_User$Message)
  Docs <- Corpus(VectorSource(Message_String))
  D_Trans_Neg(Docs)
})

getData_Table <- (function(individual){
  if(!(individual %in% individual ))
    stop("Unknown Individual")
  
  Single_User <- Bulk_Data %>% filter(Sender==individual|Receiver==individual)
  Message_String <- paste0(Single_User$Message)
  Docs <- Corpus(VectorSource(Message_String))
  D_Trans_Word_Matches(Docs)
})


getPhrase_Score <- (function(individual){
  if(!(individual %in% individual ))
    stop("Unknown Individual")
  
  Single_User <- Bulk_Data %>% filter(Sender==individual|Receiver==individual)
  Message_String <- paste0(Single_User$Message)
  Docs <- Corpus(VectorSource(Message_String))
  D_Trans_Word_Matches(Docs)
})

# Function to create data table to show exact sentences used
show_sentences <- function(individual,word){
  Single_User <- Bulk_Data %>% filter(Sender==individual|Receiver==individual)
  Sentences <- Single_User[grepl(word, Single_User$Message),]
  Sentences <- Sentences[,-1]
  Sentences
}



# Function to create time series plot for polarity score over time 

getTS_Plot <- (function(individual){
  if(!(individual %in% individual ))
    stop("Unknown Individual")
  Single_User <- Bulk_Data %>% filter(Sender==individual|Receiver==individual)
  Single_User <- Single_User %>% mutate(phrase_score = sentiment_by(get_sentences(Single_User$Message))$ave_sentiment)
  Single_User$Mon_Year <- format(as.Date(substr(Single_User$Receive_Time, start=1,stop=10), format="%d-%m-%Y"), "%Y-%m")
  Single_User$Date <- format(as.Date(as.yearmon(Single_User$Mon_Year)))
  Month <- data.frame(as.Date(as.yearmon(unique(Single_User$Mon_Year))))
  colnames(Month) <- "Date"
  Month <- Month[order(Month$Date),]
  TS_Data <- c()
  for(i in format(as.Date(Month), "%Y-%m")){
    Month_1 <- Single_User %>% filter(Mon_Year==i)
    TS_Data <- c(mean(Month_1$phrase_score),TS_Data)
  }
  Polarity_Score <- rev(TS_Data)
  Data <- data.frame(Month,Polarity_Score)
  ggplot(Data, aes(Month,Polarity_Score))+geom_line(colour="Blue")+geom_point()+xlab("2017")+ylab("Polarity Score")
  
  
})







# Server.ui
server = function(input, output){
  
  # Word cloud output code
  terms <- reactive({
    input$update
    
    isolate({
      withProgress({
        setProgress(message="Processing MOC...")
        getTermMatrix(input$selection)
      })
    })
  })
  
  
  terms_neg <- reactive({
    input$update
    
    isolate({
      withProgress({
        setProgress(message="Processing MOC...")
        getTermMatrix_Neg(input$selection)
      })
    })
  })
  
  
  wordcloud_rep <- repeatable(wordcloud)
  
  output$Sub_Wordcloud <-renderPlot({
    v<-terms()
    wordcloud_rep(names(v), v, scale=c(4,0.5),
                  min.freq=input$freq, max.words=input$max,
                  colors=brewer.pal(8,"Dark2"))
  })
  
  output$Neg_Sub_Wordcloud <-renderPlot({
    v <- terms_neg()
    wordcloud(v$word, v$freq, scale=c(4,0.5),
                  min.freq=input$freq, max.words=input$max,
                  colors=brewer.pal(8,"Dark2"))
  })
  
  # Data table output code

  terms_dt <- reactive({
    input$update
    
    isolate({
        getData_Table(input$selection)
      })
    })

  output$Word_Summary <- DT::renderDataTable({
    v <- terms_dt()
    Result},
    selection=list(mode='single', target='cell'),
    options = list(lengthMenu = c(5, 10, 25, 50), pageLength = 25)
  )
  
  
  observeEvent(input$Word_Summary_cell_clicked$value,
               {
                 output$Show_Sentences <- renderDataTable({
                   show_sentences(input$selection, input$Word_Summary_cell_clicked$value)
                 },options = list(lengthMenu = c(5, 10, 25, 50), pageLength = 25) )    
                 
               })
  
  
  
  # Time series plot
  output$TSPlot <- renderPlotly(getTS_Plot(input$selection))
    
  
}
