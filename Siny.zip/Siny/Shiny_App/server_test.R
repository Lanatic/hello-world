#Load up appropriate libraries
Sys.setenv(JAVA_HOME='C:\\Program Files (x86)\\Java\\jre8')       
library(readxl)
library(readr)
library(RJDBC)
library(dplyr)
library(tm)
library(SnowballC)
library(wordcloud)
library(memoise)
library(sentimentr)
library(tidytext)
library(RColorBrewer)
# Set up DWH connection
drv <- JDBC("com.teradata.jdbc.TeraDriver", "H:\\R\\teradata\\16.10\\terajdbc4.jar;H:\\R\\teradata\\16.10\\tdgssconfig.jar")
conn <-dbConnect(drv, "jdbc:teradata://10.65.157.101/USER=ucwr3,PASSWORD=#")
# Read in full data from DWH
Data <- dbGetQuery(conn,"select * from pfpii.ucwr3_BulkMoc_DOLOS")

Data$Sender <- toupper(Data$Sender)
Data$Receiver <- toupper(Data$Receiver)
#List of DOLOS subjects
DOLOS_ID <- library(readxl)
DOLOS_List <- read_excel("I:/Detection Team Working Folder/Jiabin/Sentiment/DOLOS_Email_List.xlsx", col_names = FALSE)
unique_DOLOS <- data.frame(unique(DOLOS_List$X__2))  
unique_DOLOS <- data.frame(lapply(unique_DOLOS, na.omit))
colnames(unique_DOLOS) <- "Email"
unique_DOLOS$Email <- toupper(unique_DOLOS$Email)

Single_User <- dbGetQuery(conn, paste0("select * from pfpii.ucwr3_BulkMoc_DOLOS where sender in (" ,"'",unique_DOLOS$Email[1],"'", ") ", 
                                       "or receiver in ","(", "'", unique_DOLOS$Email[1], "'",")"))


Single_User <- Single_User %>% mutate(phrase_score = sentiment_by(Single_User$Message)$ave_sentiment)
Single_User <- Single_User[,-1]

Message_String <- paste0(Single_User$Message)
Docs <- Corpus(VectorSource(Message_String))

toSpace <- content_transformer(function (x , pattern ) gsub(pattern, " ", x))
D_Trans <- function(x){
  x <- tm_map(x, toSpace, "/")
  x <- tm_map(x, toSpace, "@")
  x <- tm_map(x, toSpace, "\\|")
  x <- tm_map(x, content_transformer(tolower))
  x <- tm_map(x, removeNumbers)
  x <- tm_map(x, removeWords, stopwords("english"))
  x <- tm_map(x, removePunctuation)
  x <- tm_map(x, stripWhitespace)
  dtm <- TermDocumentMatrix(x)
  m <- as.matrix(dtm)
  v <<- sort(rowSums(m),decreasing=TRUE)
  i <<- data.frame(word=names(v), freq=v)
  
}

D_Trans(Docs)
#Word clouds including all words
set.seed(1234)
wordcloud(words = i$word, freq = i$freq, min.freq = 11,
        max.words=200, random.order=FALSE, rot.per=0.35, 
          colors=brewer.pal(8, "Dark2"), scale=c(1.5,0.8))


# Using appropriate dictionary for matching
sentiments <- get_sentiments("bing")
#get_sentiments("afinn")

# Positive and Negative List
positive_sentiments <- sentiments %>% filter(sentiment=="positive")
negative_sentiments <- sentiments %>% filter(sentiment=="negative")

#Word clouds including positive words
positive_matches <- intersect(i$word,positive_sentiments$word)
positive_result <- i %>% filter(word %in% positive_matches) 
positive_freq <- sum(positive_result$freq)

#wordcloud(words = positive_result$word, freq = positive_result$freq, min.freq = 1,
  #        max.words=200, random.order=FALSE, rot.per=0.35, 
   #       colors=brewer.pal(8, "Dark2"), scale=c(1.5,0.8))

#Word clouds including negative words
negative_matches <- intersect(i$word, negative_sentiments$word)
negative_result <- i %>% filter(word %in% negative_matches)
negative_freq <- sum(negative_result$freq)

#wordcloud(words = negative_result$word, freq = negative_result$freq, min.freq = 1,
 #         max.words=200, random.order=FALSE, rot.per=0.35, 
  #        colors=brewer.pal(8, "Dark2"), scale=c(1.5,0.8))



#Data table for matched words as well as Frequency
#Substantiated unique negative words
Sub_Unique_Neg <- read_csv("I:/Detection Team Working Folder/Jiabin/Sentiment/Word_Matches/Sub_Unique_Neg.csv")
Sub_Unique_Neg <- Sub_Unique_Neg[,c(3:4)]
Indiv_Sub_Unique_Neg <- intersect(as.character(i$word), as.character(Sub_Unique_Neg$Word))

#DLP key words 

#HR negative words combined with words from design and change management team

#MOC_Acroynms 




# Time series plot of average polarity score per month

my_text <- paste0(Single_User$Message)
my_text<-get_sentences(my_text)
score <- sentiment_by(my_text)[,4]

Single_User <- Single_User %>% mutate(Score2=sentiment_by(my_text)[,4])



Single_User <- Single_User %>% mutate(phrase_score = sentiment_by(Single_User$Message)$ave_sentiment)

Single_User <- Single_User[order(Single_User$phrase_score),]

Single_User$Mon_Year <- format(as.Date(substr(Single_User$Receive_Time, start=1,stop=10), format="%d-%m-%Y"), "%Y-%m")
Single_User$Date <- format(as.Date(as.yearmon(Single_User$Mon_Year)))
unique(Single_User$Mon_Year)

TS_Data <- c()
Month <- c()
for(i in unique(Single_User$Mon_Year)){
  Unique_Month <- Single_User %>% filter(Date==i)
  TS_Data <- c(mean(Unique_Month$phrase_score),TS_Data)
  Month <- c(i,Month)
}
Month <- data.frame(as.Date(as.yearmon(Month)))
colnames(Month) <- "Date"
Month[order(Month$Date),]

Single_User$Mon_Year <- format(as.Date(substr(Single_User$Receive_Time, start=1,stop=10), format="%d-%m-%Y"), "%Y-%m")

library(zoo)
as.Date(as.yearmon("2017-07"))

Unique_Month <- Single_User %>% filter(Mon_Year=="07/2017")
Result <- c(mean(Unique_Month$phrase_score))


# Load in library zoo, use as.yearmon and reorder data frame
Month <- data.frame(as.Date(as.yearmon(unique(Single_User$Mon_Year))))
colnames(Month) <- "Date"
Unique_Month <- Month[order(Month$Date),]

Single_User$Mon_Year <- format(as.Date(substr(Single_User$Receive_Time, start=1,stop=10), format="%d-%m-%Y"), "%Y-%m")
Single_User$Date <- format(as.Date(as.yearmon(Single_User$Mon_Year)))


TS_Data <- c()
for(i in format(as.Date(Unique_Month), "%Y-%m")){
  Month <- Single_User %>% filter(Mon_Year==i)
  TS_Data <- c(mean(Month$phrase_score),TS_Data)
}
TS_Data <- rev(TS_Data)

Data <- data.frame(Unique_Month,TS_Data)
ggplot(Data, aes(Unique_Month,TS_Data))+geom_line()+xlab("2017")+ylab("Polarity Score")



D_Trans <- function(x){
  x <- tm_map(x, toSpace, "/")
  x <- tm_map(x, toSpace, "@")
  x <- tm_map(x, toSpace, "\\|")
  x <- tm_map(x, content_transformer(tolower))
  x <- tm_map(x, removeNumbers)
  x <- tm_map(x, removeWords, stopwords("english"))
  x <- tm_map(x, removePunctuation)
  x <- tm_map(x, stripWhitespace)
  dtm <- TermDocumentMatrix(x)
  m <- as.matrix(dtm)
  sort(rowSums(m),decreasing=TRUE)
  i <<- data.frame(word=names(v), freq=v)
  
}

Individuals <<- list("ATHENA.SIATOS@ATO.GOV.AU"="ATHENA.SIATOS@ATO.GOV.AU",
                     "RECEP.YERLIKAYA@ATO.GOV.AU"="RECEP.YERLIKAYA@ATO.GOV.AU")
getTermMatrix <- memoise(function(individual){
  if(!(individual %in% individual ))
    stop("Unknown Individual")
  
  Single_User <- dbGetQuery(conn, paste0("select * from pfpii.ucwr3_BulkMoc_DOLOS where sender in (" ,"'",individual,"'", ") ", 
                                         "or receiver in ","(", "'", individual, "'",")"))
  Message_String <- paste0(Single_User$Message)
  Docs <- Corpus(VectorSource(Message_String))
  D_Trans(Docs)
  
})

# Server.ui
server = function(input, output){
  individuals <- reactive({
    input$update
    
    isolate({
      withProgress({
        setProgress(message="Processing MOC...")
        getTermMatrix(input$selection)
      })
    })
  })
  wordcloud_rep <- repeatable(wordcloud)
  
  output$Sub_Wordcloud <-renderPlot({
    v<-terms()
    wordcloud_rep(names(v), v, scale=c(4,0.5),
                  min.freq=input$freq, max.words=input$max,
                  colors=brewer.pal(8,"Dark2"))
  })
}


