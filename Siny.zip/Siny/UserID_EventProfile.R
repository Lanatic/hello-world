#Load up appropriate libraries
Sys.setenv(JAVA_HOME='C:\\Program Files (x86)\\Java\\jre8')       
library(readxl)
library(readr)
library(RJDBC)
library(dplyr)
library(tm)
library(SnowballC)
library(wordcloud)
library(memoise)
library(sentimentr)
library(tidytext)
library(zoo)
library(ggplot2)
# Read in userID Email list
UserName_Email<- read_excel("I:/Detection Team/Working Folder/Jiabin/Sentiment/UserName_Email_Sub.xlsx")
Df <- UserName_Email[,c(4:5)]
Df <- Df[complete.cases(Df),]
colnames(Df)<- c("UserID", "Email")
# Read in userID Fraud event profile list

library(readxl)
KPI_spreadsheet <- read_excel("M:/Response Team/KPI_spreadsheet.xlsx")
KPI <- KPI_spreadsheet[,c(7,22)]
colnames(KPI) <- c("Category", "UserID")

Combined_DF <- merge(Df,KPI, by="UserID", all.x=TRUE)
Categories <- unique(Combined_DF$Category)

# Read in bulk MOC data
Pass <- read_table("H:/DWHCred.txt",col_names = FALSE)
drv <- JDBC("com.teradata.jdbc.TeraDriver", "H:\\R\\teradata\\16.10\\terajdbc4.jar;H:\\R\\teradata\\16.10\\tdgssconfig.jar")
conn <-dbConnect(drv, paste0("jdbc:teradata://10.65.157.101/USER=",Pass$X1[1], ",PASSWORD=",Pass$X1[2]))

# Read in full data from DWH
Data <- dbGetQuery(conn,"select * from pfpii.ucwr3_BulkMoc_User_Sub")

Data$Sender <- toupper(Data$Sender)
Data$Receiver <- toupper(Data$Receiver)

# Unauthorised Access
UA <- Combined_DF %>% filter(Category=="Unauthorised access")

# Misuse of ATO facilities
MOAF <- Combined_DF %>% filter(Category=="Fraud-Revenue")

MOAF_Data <- data.frame(c(0,0,0,0,0,0))
for(i in MOAF$Email){
  Single_User <- Data %>% filter(Sender==i|Receiver==i)
  Single_User <- ifelse(nrow(Single_User)==0,c(0,0,0,0,0,0), Single_User )
  MOAF_Data <<- data.frame(rbind(Single_User), MOAF_Data)
}

#Create word clouds for MOAF individuals
DF1 <- Data[Data$Receiver %in% MOAF$Email,]
DF2 <- Data[Data$Sender %in% MOAF$Email,]

DF <- data.frame(rbind(DF1,DF2))

combined_freq <- data.frame(cbind(0,0))
colnames(combined_freq)<- c("word","freq")

Message_String <- paste0(DF$Message)

# Obtain full word cloud 
sequence <- seq(0, length(Message_String), 5000)
for(i in sequence){
  if(i==0){
    Message_String <- paste0(DF$Message)[0:5000]
    Docs <- Corpus(VectorSource(Message_String))
    D_Trans(Docs)
    #combined_freq <- combined_freq %>% filter(combined_freq$freq > 24)
  } else if(i < sequence[length(sequence)]){
    Message_String <- paste0(DF$Message)[(i+1):(i+5000)]
    Docs <- Corpus(VectorSource(Message_String))
    D_Trans(Docs)
    #combined_freq <- combined_freq %>% filter(combined_freq$freq >24)
    
  }else if( i==sequence[length(sequence)]){
    Message_String <- paste0(DF$Message)[i:length(DF$Message)]
    Docs <- Corpus(VectorSource(Message_String))
    D_Trans(Docs)
    #combined_freq <- combined_freq %>% filter(combined_freq$freq >24) 
  }
}

set.seed(1234)
i <- combined_freq
wordcloud(words = i$word, freq = i$freq, min.freq = 25,
          max.words=200, random.order=FALSE, rot.per=0.35, 
          colors=brewer.pal(8, "Dark2"), scale=c(1.5,0.8))

#Obtain negative wordcloud


#Create word clouds for MOAF individuals
MOAF <- Combined_DF %>% filter(Category=="Misuse of IT facilities")
DF1 <- Data[Data$Receiver %in% MOAF$Email,]
DF2 <- Data[Data$Sender %in% MOAF$Email,]

DF <- data.frame(rbind(DF1,DF2))

combined_freq <- data.frame(cbind(0,0))
colnames(combined_freq)<- c("word","freq")

Message_String <- paste0(DF$Message)


combined_freq <- data.frame(cbind(0,0))
colnames(combined_freq)<- c("word","freq")


sequence <- seq(0, length(Message_String), 5000)
for(i in sequence){
  if(i==0){
    Message_String <- paste0(DF$Message)[0:5000]
    Docs <- Corpus(VectorSource(Message_String))
    D_Trans(Docs)
  } else if(i < sequence[length(sequence)]){
    Message_String <- paste0(DF$Message)[(i+1):(i+5000)]
    Docs <- Corpus(VectorSource(Message_String))
    D_Trans(Docs)
    
  }else if( i==sequence[length(sequence)]){
    Message_String <- paste0(DF$Message)[i:length(DF$Message)]
    Docs <- Corpus(VectorSource(Message_String))
    D_Trans(Docs)
  }
}
negative_sentiments <- sentiments %>% filter(sentiment=="negative")

negative_matches <- intersect(combined_freq$word, negative_sentiments$word)
negative_result <- combined_freq %>% filter(word %in% negative_matches)
colnames(negative_result) <- c("Word", "Frequency")
negative_result <- negative_result[order(negative_result$Frequency, decreasing = TRUE),]

write.csv(negative_result, "I:/Detection Team/Working Folder/Jiabin/OBA_Filter/Word_List/MOIF.csv", row.names = FALSE)

wordcloud(words = negative_result$word, freq = negative_result$freq, min.freq = 25,
      max.words=200, random.order=FALSE, rot.per=0.35, 
       colors=brewer.pal(8, "Dark2"), scale=c(1.5,0.8))





Docs <- Corpus(VectorSource(Message_String))
combined_freq <- combined_freq %>% filter(combined_freq$freq >24)

D_Trans(Docs)

toSpace <- content_transformer(function (x , pattern ) gsub(pattern, " ", x))

D_Trans <- function(x){
  x <- tm_map(x, toSpace, "/")
  x <- tm_map(x, toSpace, "@")
  x <- tm_map(x, toSpace, "\\|")
  x <- tm_map(x, content_transformer(tolower))
  x <- tm_map(x, removeNumbers)
  x <- tm_map(x, removeWords, stopwords("english"))
  x <- tm_map(x, removePunctuation)
  x <- tm_map(x, stripWhitespace)
  dtm <- TermDocumentMatrix(x)
  m <- as.matrix(dtm)
  v <<- sort(rowSums(m),decreasing=TRUE)
  i <<- data.frame(word=names(v), freq=v)
  combined_freq <<- aggregate(cbind(freq) ~ word, rbind(combined_freq,i), sum)
  
}

D_Trans_2 <- function(x){
  x <- tm_map(x, toSpace, "/")
  x <- tm_map(x, toSpace, "@")
  x <- tm_map(x, toSpace, "\\|")
  x <- tm_map(x, content_transformer(tolower))
  x <- tm_map(x, removeNumbers)
  x <- tm_map(x, removeWords, stopwords("english"))
  x <- tm_map(x, removePunctuation)
  x <- tm_map(x, stripWhitespace)
  dtm <- TermDocumentMatrix(x)
  m <- as.matrix(dtm)
  v <<- sort(rowSums(m),decreasing=TRUE)
  i_2 <<- data.frame(word=names(v), freq=v)
  
}

i$rn <- rownames(i)
i_2$rn <- rownames(i_2)
i <- i[,-3]
i_2 <- i_2[,-3]
res <- aggregate(cbind(freq) ~ word, rbind(i,i_2), sum)

#merge(i,i_2, by=c("word","freq"))
D_Trans(Docs)
#Word clouds including all words
set.seed(1234)
i <- combined_freq
wordcloud(words = i$word, freq = i$freq, min.freq = 25,
          max.words=200, random.order=FALSE, rot.per=0.35, 
          colors=brewer.pal(8, "Dark2"), scale=c(1.5,0.8))



# Creating polarity score plots for each event category 

Single_User <- Bulk_Data %>% filter(Sender==MOAF$Email[1]|Receiver==MOAF$Email[1])
Single_User <- Single_User %>% mutate(phrase_score = sentiment_by(get_sentences(Single_User$Message))$ave_sentiment)
Single_User$Mon_Year <- format(as.Date(substr(Single_User$Receive_Time, start=1,stop=10), format="%d-%m-%Y"), "%Y-%m")
Single_User$Date <- format(as.Date(as.yearmon(Single_User$Mon_Year)))
Month <- data.frame(as.Date(as.yearmon(unique(Single_User$Mon_Year))))
colnames(Month) <- "Date"
Month <- Month[order(Month$Date),]
TS_Data <- c()
for(i in format(as.Date(Month), "%Y-%m")){
  Month_1 <- Single_User %>% filter(Mon_Year==i)
  TS_Data <- c(mean(Month_1$phrase_score),TS_Data)
}
Polarity_Score <- rev(TS_Data)
Data <- data.frame(Month,Polarity_Score)
ggplot(Data, aes(Month,Polarity_Score))+geom_line(colour="Blue")+geom_point()+xlab("2017")+ylab("Polarity Score")


#Creating polarity time series plots

MOAF <- Combined_DF %>% filter(Category=="Advice only")
DF1 <- Data[Data$Receiver %in% MOAF$Email,]
DF2 <- Data[Data$Sender %in% MOAF$Email,]
DF <- data.frame(rbind(DF1,DF2))
DF <- DF %>% mutate(pharse_score = sentiment_by(get_sentences(DF$Message))$ave_sentiment)
DF$Mon_Year <- format(as.Date(substr(DF$Receive_Time, start=1,stop=10), format="%d-%m-%Y"), "%Y-%m")
DF$Date <- format(as.Date(as.yearmon(DF$Mon_Year)))
Month <- data.frame(as.Date(as.yearmon(unique(DF$Mon_Year))))
colnames(Month) <- "Date"
Month <- Month[order(Month$Date),]
TS_Data <- c()
for(i in format(as.Date(Month), "%Y-%m")){
  Month_1 <- DF %>% filter(Mon_Year==i)
  TS_Data <- c(mean(Month_1$pharse_score), TS_Data)
}
Polarity_Score <- rev(TS_Data)
Data1 <- data.frame(Month,Polarity_Score)
ggplot(Data1, aes(Month,Polarity_Score))+geom_line(colour="Blue")+geom_point()+xlab("2017")+ylab("Polarity Score")+
  ggtitle("Average polarity score per month across 2017 for Fraud-Administration")


for(i in Categories){
  MOAF <- Combined_DF %>% filter(Category==i)
  DF1 <- Data[Data$Receiver %in% MOAF$Email,]
  DF2 <- Data[Data$Sender %in% MOAF$Email,]
  DF <- data.frame(rbind(DF1,DF2))
  DF <- DF %>% mutate(pharse_score = sentiment_by(get_sentences(DF$Message))$ave_sentiment)
  DF$Mon_Year <- format(as.Date(substr(DF$Receive_Time, start=1,stop=10), format="%d-%m-%Y"), "%Y-%m")
  DF$Date <- format(as.Date(as.yearmon(DF$Mon_Year)))
  Month <- data.frame(as.Date(as.yearmon(unique(DF$Mon_Year))))
  colnames(Month) <- "Date"
  Month <- Month[order(Month$Date),]
  TS_Data <- c()
  for(i in format(as.Date(Month), "%Y-%m")){
    Month_1 <- DF %>% filter(Mon_Year==i)
    TS_Data <- c(mean(Month_1$pharse_score), TS_Data)
  }
  Polarity_Score <- rev(TS_Data)
  Data1 <- data.frame(Month,Polarity_Score)
  ggplot(Data1, aes(Month,Polarity_Score))+geom_line(colour="Blue")+geom_point()+xlab("2017")+ylab("Polarity Score")+
    ggtitle(paste0("Average polarity score per month across 2017 for ",i))
  
}

# Read in Time Series Annual 
Time_Series_Annual <- read_excel("I:/Detection Team/Working Folder/Jiabin/Sentiment/Time_Series_Annual.xlsx")
df <- data.frame()
sp <- ggplot(df) + geom_point() + xlim(0, 1) + ylim(0, max(Time_Series_Annual$`Polarity Score`))
sp <- sp + geom_hline(yintercept = Time_Series_Annual$`Polarity Score`[1], color="red")
sp <-sp + geom_hline(yintercept = Time_Series_Annual$`Polarity Score`[2], color="blue")
sp<- sp+geom_hline(yintercept = Time_Series_Annual$`Polarity Score`[3], color="orange")
sp


Total_years<- data.frame(rbind(TS1,TS2,TS3))
Time_Series_Annual$CommonDate<- rep(as.Date(c("2017-01-01","2017-02-01","2017-03-01","2017-04-01","2017-05-01","2017-06-01", "2017-07-01","2017-08-01","2017-09-01","2017-10-01","2017-11-01","2017-12-01")),11)
Df <-data.frame(cbind(rep(Time_Series_Annual$Category,12), rep(Time_Series_Annual$`Polarity Score`,12)))

Df$Date<-c(rep(as.Date("2017-01-01"),11),rep(as.Date("2017-02-01"),11),rep(as.Date("2017-03-01"),11),rep(as.Date("2017-04-01"),11),rep(as.Date("2017-05-01"),11),rep(as.Date("2017-06-01"),11),rep(as.Date("2017-07-01"),11),rep(as.Date("2017-08-01"),11),rep(as.Date("2017-09-01"),11),rep(as.Date("2017-10-01"),11),rep(as.Date("2017-11-01"),11),rep(as.Date("2017-12-01"),11))

colnames(Df)<- c("Category","Polarity Score", "Date")
Df$`Polarity Score` <- as.numeric(levels(Df$`Polarity Score`))[Df$`Polarity Score`]
ggplot(data=Df, mapping = aes(x=Date, y=`Polarity Score`, colour=Category))+geom_line()+ xlab("Date")+ scale_x_date(labels=function(x) format(x,"%d-%b"))
Df$`Polarity Score`

Df[Df$Category=="Fraud-Revenue",]$`Polarity Score` <- 0
Df[is.na(Df)]<- 0

SPD <- read_csv("I:/Detection Team/Working Folder/Jiabin/Sentiment/Sentiment_Plot_Data.csv")
SPD$Date <- as.Date(SPD$Date)
ggplot(data=SPD, mapping = aes(x=Date, y=`Polarity Score`, colour=Category))+geom_line()+ xlab("Date")+ scale_x_date(labels=function(x) format(x,"%d-%b"))



