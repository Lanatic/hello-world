install.packages("sentimentr")
install.packages("tm")
install.packages("dplyr")
install.packges("stringr")
install.packages("wordcloud")
install.packages("SnowballC")
install.packages("RColorBrewer")
installed.packages("Hmisc")
install.packages("readr")
install.packages("tidytext")
install.packages("qdap")

library(tm)
library(dplyr)
library(stringr)
library(wordcloud)
library(SnowballC)
library(RColorBrewer)
library(Hmisc)
library(readr)
library(tidytext)
library(sentimentr)
library(qdap)

mytext <- c(
  'i really really hate',
  'I am the best friend.',
  'Do you really like it?  I\'m not a fan',
  'hate hi hi'
)
mytext <- get_sentences(mytext)
sentiment_by(mytext)

library(readtext)
library(readr)
Moc1<- read_csv("A:/TEAL/Multi MoC/MoC_antonia.mammoliti@ato.gov.au_2017.10.30-2017.11.30.txt")

file_loc <- "A:/TEAL/Multi MoC/MoC_alison.tarchichi@ato.gov.au_2017.10.30-2017.11.30.txt"
filename <- file_loc
con <- file(filename,open="r")
line <- readLines(con)

Data <- data.frame(line)
colnames(Data) <- "Message"

New_Data <- Data %>% filter(!str_detect(Message, 'ato'))
New_Data <- New_Data[!apply(New_Data=="",1,all),]
New_Data <- data.frame(New_Data)
colnames(New_Data) <- "Message"

my_text <- as.character(New_Data$Message)

mytext <- get_sentences(my_text)
score <- data.frame(New_Data,sentiment_by(mytext)) 

Rank_score <- score[order(score$ave_sentiment),]



mytext <- c(
  'i really really hate',
  'I am the best friend.',
  'Do you really like it?  I\'m not a fan',
  'hate hi hi'
)
mytext <- get_sentences(mytext)
sentiment_by(mytext)

Sys.setenv(JAVA_HOME='C:\\Program Files (x86)\\Java\\jre8')

install.packages("hunspell")
library(hunspell)
words <- c("beer", "wiskey", "wine")
correct <- hunspell_check(words)
print(correct)

hunspell_suggest(words[!correct])


