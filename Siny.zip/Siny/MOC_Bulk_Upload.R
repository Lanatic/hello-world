



file1 <- read_delim("A:/SILVER/Bulk Moc Silver/DOLOS/RTCLog_2017_Jun_30.txt", 
                    "|", escape_double = FALSE, trim_ws = TRUE, col_names = FALSE)



for(i in 1:nrow(file1)){
  if(is.na(file1$X2[i])==TRUE){
    file1$X5[i-1] <- paste(file1$X5[i-1],file1$X1[i])
    file1 <- file1[-i,]
    file1<- rbind(c(0,0,0,0,0),file1)
  }
}

file1 <- file1[!(file1$X1==0),]
write.csv(file1, "I:/Detection Team Working Folder/Jiabin/Other/test.csv", row.names = FALSE)


Missing_Lines_Upload_31_Aug2017 <- read_delim("I:/Detection Team Working Folder/Jiabin/Sentiment/Missing_Lines_Upload_31_Aug2017.txt", 
                                              "|", escape_double = FALSE, trim_ws = TRUE)


Pass <- read_table("H:/DWHCred.txt",col_names = FALSE)
drv <- JDBC("com.teradata.jdbc.TeraDriver", "H:\\R\\teradata\\16.10\\terajdbc4.jar;H:\\R\\teradata\\16.10\\tdgssconfig.jar")
conn <-dbConnect(drv, paste0("jdbc:teradata://10.65.157.101/USER=",Pass$X1[1], ",PASSWORD=",Pass$X1[2]))

eg1 <- dbGetQuery(conn, "select * from pfpii.uclhy_moctest")
write.csv(eg1,"I:/Detection Team/Working Folder/Jiabin/Other/test.csv" )
